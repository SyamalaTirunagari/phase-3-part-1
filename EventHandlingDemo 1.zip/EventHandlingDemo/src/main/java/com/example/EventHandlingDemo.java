package com.example;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EventHandlingDemo {
    public static void main(String[] args) {
        // Load the Spring context from XML configuration file
        ClassPathXmlApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext.xml");

        // Retrieve the EventPublisher bean
        EventPublisher eventPublisher = context.getBean(EventPublisher.class);

        // Register a custom event listener
        context.addApplicationListener(new CustomEventListener());

        // Publish a custom event
        eventPublisher.publishCustomEvent();

        // Close the context
        context.close();
    }
}
